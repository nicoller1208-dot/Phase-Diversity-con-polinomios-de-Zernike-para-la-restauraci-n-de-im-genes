# Phase Diversity con Zernike — versión final

Proyecto numérico de Óptica de Fourier para estimar aberraciones mediante Phase Diversity y comparar una diversidad convencional con una diversidad extendida.

## Estructura final

```text
codigo_final/
├── main.py
├── requirements.txt
└── fourier_pd_final/
    ├── config.py
    ├── optics_final/
    │   ├── zernike.py
    │   └── system.py
    ├── simulation_final/
    │   └── data.py
    ├── algorithms_final/
    │   └── phase_diversity.py
    ├── analysis_final/
    │   ├── metrics.py
    │   ├── experiments.py
    │   ├── aberration_cases.py
    │   └── random_aberrations.py
    ├── validation_final/
    │   └── checks.py
    ├── visualization_final/
    │   └── plots.py
    └── utils_final/
        └── io.py
```

## Ejecución

```bash
pip install -r requirements.txt
python main.py
```

Las nuevas salidas se crean en `salida_fourier_final/`.

Los archivos Python de esta entrega no contienen comentarios ni docstrings explicativos. Todos los imports fueron actualizados a los nombres de carpetas con sufijo `_final`.
