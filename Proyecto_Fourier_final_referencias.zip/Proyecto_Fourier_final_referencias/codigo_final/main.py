from __future__ import annotations
from pathlib import Path
import json
import numpy as np
from fourier_pd_final.analysis_final.aberration_cases import coefficient_rows_from_representatives, run_aberration_case_study
from fourier_pd_final.analysis_final.random_aberrations import run_random_aberration_study
from fourier_pd_final.analysis_final.experiments import run_main_comparison, run_monte_carlo, run_regularization_sensitivity, select_d5, summarize_monte_carlo
from fourier_pd_final.config import Config
from fourier_pd_final.optics_final.system import FourierPDModel
from fourier_pd_final.utils_final.io import ensure_output_dirs, save_config, save_main_results, save_runtime_info, write_dict_csv
from fourier_pd_final.validation_final.checks import run_validations
from fourier_pd_final.visualization_final.plots import plot_coefficients, plot_convergence, plot_d5_selection, plot_images, plot_metrics, plot_monte_carlo, plot_psfs, plot_regularization_sensitivity, plot_validation_gram, plot_wavefronts, plot_aberration_case_summary, plot_aberration_case_coefficients, plot_aberration_case_wavefronts, plot_aberration_case_differences, plot_zernike_modes, plot_random_aberration_differences, plot_random_aberration_coefficients, plot_random_aberration_summary

def print_validation_summary(records) -> None:
    print('\n=== VALIDACIONES ===')
    for r in records:
        print(f"[{r['Estado']}] {r['Prueba']}: {r['Valor']}")

def print_main_summary(main: dict, cfg: Config) -> None:
    true_coeffs = np.asarray(cfg.true_coeffs)
    conv = main['result_conv']['coeffs']
    ext = main['result_ext']['coeffs']
    mc = main['metrics_conv']
    me = main['metrics_ext']
    print('\n=== RESULTADOS ILUSTRATIVOS (UNA SEMILLA) ===')
    print(f'Modos ANSI/OSA          : {cfg.modes}')
    print(f'Coeficientes teóricos   : {np.round(true_coeffs, 5)} rad')
    print(f'Estimados PD conv.      : {np.round(conv, 5)} rad')
    print(f'Estimados PD extendida  : {np.round(ext, 5)} rad')
    print(f'D4 convencional         : {cfg.d4:.3f} rad')
    print(f"D5 seleccionado         : {main['selected_d5']:.3f} rad")
    print(f"RMSE_C conv./ext.       : {mc['RMSE_C']:.5f} / {me['RMSE_C']:.5f} rad")
    print(f"RMSE_W conv./ext.       : {mc['RMSE_W']:.5f} / {me['RMSE_W']:.5f} rad")
    print(f"PSNR conv./ext.         : {mc['PSNR']:.3f} / {me['PSNR']:.3f} dB")
    print(f"SSIM conv./ext.         : {mc['SSIM']:.5f} / {me['SSIM']:.5f}")

def print_mc_summary(summary_rows) -> None:
    print('\n=== MONTE CARLO: EVALUACIÓN FINAL ===')
    for r in summary_rows:
        if r['Metodo'] in ('PD convencional', 'PD extendida'):
            print(f"{r['Metodo']}: RMSE_C={r['RMSE_C_mean']:.5f}±{r['RMSE_C_std']:.5f} rad, PSNR={r['PSNR_mean']:.3f}±{r['PSNR_std']:.3f} dB")
        else:
            print(f"Diferencia pareada ext-conv: ΔRMSE_C={r['RMSE_C_mean']:.5f} rad, ΔPSNR={r['PSNR_mean']:.3f} dB, victorias RMSE={r.get('Victorias_RMSE_ext', 0)}/{r['N_semillas']}, victorias PSNR={r.get('Victorias_PSNR_ext', 0)}/{r['N_semillas']}")

def main() -> None:
    cfg = Config()
    root = Path(__file__).resolve().parent
    output, figures = ensure_output_dirs(root, cfg)
    save_config(cfg, output)
    print('Construyendo modelo óptico...')
    model = FourierPDModel(cfg)
    if cfg.run_validations:
        print('Ejecutando validaciones del modelo...')
        validation_records, gram = run_validations(model, cfg)
        print_validation_summary(validation_records)
        write_dict_csv(output / 'validaciones.csv', validation_records)
        plot_validation_gram(model, gram, figures)
        failed = [r for r in validation_records if r['Estado'] == 'FAIL']
        if failed and cfg.stop_on_validation_failure:
            names = ', '.join((r['Prueba'] for r in failed))
            raise RuntimeError(f'Se detiene la ejecución: fallaron validaciones: {names}')
    if cfg.run_d5_selection:
        print('\nSeleccionando D5 con semillas independientes...')
        selection = select_d5(model, cfg)
        selected_d5 = selection['selected_d5']
        write_dict_csv(output / 'seleccion_D5_resumen.csv', selection['summary_rows'])
        write_dict_csv(output / 'seleccion_D5_detalle.csv', selection['raw_rows'])
        plot_d5_selection(selection, figures)
        print(f'D5 seleccionado = {selected_d5:.3f} rad')
        print(f"Estado de selección: {selection['selection_status']}")
        print(f"Criterio: {selection['selection_rule']}")
    else:
        selected_d5 = cfg.d5_fallback
        selection = {'selected_d5': selected_d5, 'selection_status': 'seleccion_automatica_desactivada', 'selection_rule': 'Valor fijo de respaldo; selección automática desactivada.', 'summary_rows': [], 'raw_rows': []}
    save_runtime_info(selected_d5, selection['selection_rule'], output)
    print('\nEjecutando comparación principal ilustrativa...')
    main_result = run_main_comparison(model, cfg, selected_d5)
    print_main_summary(main_result, cfg)
    plot_zernike_modes(model, figures)
    plot_wavefronts(model, main_result['result_conv'], main_result['result_ext'], figures)
    plot_psfs(model, cfg, selected_d5, figures)
    plot_images(main_result, model, figures)
    plot_coefficients(model, main_result, figures)
    plot_metrics(main_result, figures)
    plot_convergence(main_result, figures)
    save_main_results(model, main_result, output)
    mc_summary = []
    if cfg.run_monte_carlo:
        print('\nEjecutando Monte Carlo con semillas de evaluación independientes...')
        mc_rows = run_monte_carlo(model, cfg, selected_d5, warm_main=main_result)
        mc_summary = summarize_monte_carlo(mc_rows)
        write_dict_csv(output / 'monte_carlo_detalle.csv', mc_rows)
        write_dict_csv(output / 'monte_carlo_resumen.csv', mc_summary)
        plot_monte_carlo(mc_rows, figures)
        print_mc_summary(mc_summary)
    if cfg.run_regularization_sensitivity:
        print('\nEjecutando sensibilidad a la regularización...')
        sensitivity_rows = run_regularization_sensitivity(model, cfg, selected_d5)
        write_dict_csv(output / 'sensibilidad_regularizacion.csv', sensitivity_rows)
        plot_regularization_sensitivity(sensitivity_rows, figures)
    aberration_study = None
    if cfg.run_aberration_cases:
        print('\nEvaluando distintos escenarios de aberración...')
        aberration_study = run_aberration_case_study(cfg, selected_d5)
        write_dict_csv(output / 'casos_aberracion_detalle.csv', aberration_study['detail_rows'])
        write_dict_csv(output / 'casos_aberracion_resumen.csv', aberration_study['summary_rows'])
        write_dict_csv(output / 'casos_aberracion_pareado.csv', aberration_study['paired_rows'])
        write_dict_csv(output / 'casos_aberracion_coeficientes_representativos.csv', coefficient_rows_from_representatives(aberration_study))
        plot_aberration_case_summary(aberration_study, figures)
        plot_aberration_case_coefficients(aberration_study, figures)
        plot_aberration_case_wavefronts(aberration_study, figures)
        plot_aberration_case_differences(aberration_study, figures)
    random_study = None
    if cfg.run_random_aberrations:
        print('\nEvaluando aberraciones sintéticas aleatorias controladas...')
        random_study = run_random_aberration_study(model, cfg, selected_d5)
        write_dict_csv(output / 'aleatorios_detalle.csv', random_study['detail_rows'])
        write_dict_csv(output / 'aleatorios_pareado.csv', random_study['paired_rows'])
        write_dict_csv(output / 'aleatorios_resumen.csv', random_study['summary_rows'])
        plot_random_aberration_differences(random_study, figures)
        plot_random_aberration_coefficients(random_study, cfg, figures)
        plot_random_aberration_summary(random_study, figures)
        rs = random_study['summary']
        print(f"  PD extendida mejora RMSE_C en {rs['Victorias_RMSE_ext']}/{rs['N_casos']} casos ({rs['Porcentaje_RMSE_ext']:.1f}%).")
        print(f"  PD extendida mejora PSNR en {rs['Victorias_PSNR_ext']}/{rs['N_casos']} casos ({rs['Porcentaje_PSNR_ext']:.1f}%).")
        print(f"  Mejora simultáneamente RMSE_C y PSNR en {rs['Victorias_ambas_ext']}/{rs['N_casos']} casos ({rs['Porcentaje_ambas_ext']:.1f}%).")
    summary_json = {'D5_seleccionado_rad': selected_d5, 'estado_seleccion_D5': selection['selection_status'], 'criterio_D5': selection['selection_rule'], 'semillas_seleccion': list(cfg.selection_seeds), 'semillas_evaluacion': list(cfg.evaluation_seeds), 'main_seed': cfg.main_seed, 'validaciones_activas': cfg.run_validations, 'monte_carlo_activo': cfg.run_monte_carlo, 'sensibilidad_regularizacion_activa': cfg.run_regularization_sensitivity, 'casos_aberracion_activos': cfg.run_aberration_cases, 'semillas_casos_aberracion': list(cfg.aberration_case_seeds), 'estudio_aleatorio_activo': cfg.run_random_aberrations, 'n_casos_aleatorios': cfg.n_random_aberrations, 'semilla_coeficientes_aleatorios': cfg.random_aberration_seed, 'semillas_ruido_aleatorias': list(cfg.random_aberration_noise_seeds)}
    with open(output / 'resumen_ejecucion.json', 'w', encoding='utf-8') as f:
        json.dump(summary_json, f, indent=2, ensure_ascii=False)
    print(f'\nResultados guardados en: {output}')
    print(f'Figuras guardadas en:    {figures}')
if __name__ == '__main__':
    main()
