from __future__ import annotations
import math
from typing import Tuple
import numpy as np

def ansi_nm(j: int) -> Tuple[int, int]:
    if j < 0:
        raise ValueError('El índice ANSI/OSA debe ser no negativo.')
    for n in range(100):
        for m in range(-n, n + 1, 2):
            if (n * (n + 2) + m) // 2 == j:
                return (n, m)
    raise ValueError(f'No se pudo convertir el índice j={j}.')

def radial_zernike(n: int, m_abs: int, rho: np.ndarray) -> np.ndarray:
    if m_abs > n or (n - m_abs) % 2 != 0:
        return np.zeros_like(rho, dtype=float)
    radial = np.zeros_like(rho, dtype=float)
    for s in range((n - m_abs) // 2 + 1):
        numerator = (-1) ** s * math.factorial(n - s)
        denominator = math.factorial(s) * math.factorial((n + m_abs) // 2 - s) * math.factorial((n - m_abs) // 2 - s)
        radial += numerator / denominator * rho ** (n - 2 * s)
    return radial

def zernike_mode(j: int, rho: np.ndarray, theta: np.ndarray, aperture: np.ndarray) -> np.ndarray:
    n, m = ansi_nm(j)
    m_abs = abs(m)
    radial = radial_zernike(n, m_abs, rho)
    norm = np.sqrt(2.0 * (n + 1) / (1.0 + int(m == 0)))
    angular = np.cos(m * theta) if m >= 0 else np.sin(m_abs * theta)
    return norm * radial * angular * aperture
