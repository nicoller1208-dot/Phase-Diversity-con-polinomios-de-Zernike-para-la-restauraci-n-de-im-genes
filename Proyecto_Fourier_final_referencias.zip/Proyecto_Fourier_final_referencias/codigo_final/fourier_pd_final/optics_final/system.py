from __future__ import annotations
from pathlib import Path
from typing import Dict, Optional, Sequence, Tuple
import numpy as np
from skimage import color, data, io, transform
from ..config import Config
from .zernike import zernike_mode
Diversity = Dict[int, float]

class FourierPDModel:

    def __init__(self, cfg: Config):
        self.cfg = cfg
        self.N = cfg.N
        x = np.linspace(-1.0, 1.0, self.N, endpoint=False)
        self.dx = float(x[1] - x[0])
        self.X, self.Y = np.meshgrid(x, x)
        self.rho = np.sqrt(self.X ** 2 + self.Y ** 2)
        self.theta = np.arctan2(self.Y, self.X)
        self.aperture = (self.rho <= 1.0).astype(float)
        required_modes = set(cfg.modes) | {4, 5}
        self.Z = {j: zernike_mode(j, self.rho, self.theta, self.aperture) for j in sorted(required_modes)}
        self.object = self._load_object(cfg.object_path)
        self.object_F = np.fft.fft2(self.object)

    def _load_object(self, object_path: Optional[str]) -> np.ndarray:
        if object_path is None:
            obj = data.camera().astype(float) / 255.0
        else:
            p = Path(object_path)
            if not p.exists():
                raise FileNotFoundError(f'No existe la imagen: {p}')
            obj = io.imread(p)
            if obj.ndim == 3:
                if obj.shape[-1] == 4:
                    obj = color.rgba2rgb(obj)
                obj = color.rgb2gray(obj)
            obj = obj.astype(float)
            obj -= obj.min()
            if obj.max() > 0:
                obj /= obj.max()
        obj = transform.resize(obj, (self.N, self.N), anti_aliasing=True, preserve_range=True).astype(float)
        obj -= obj.min()
        if obj.max() > 0:
            obj /= obj.max()
        return obj

    def wavefront(self, coeffs: Sequence[float]) -> np.ndarray:
        coeffs = np.asarray(coeffs, dtype=float)
        if coeffs.size != len(self.cfg.modes):
            raise ValueError('Número incorrecto de coeficientes.')
        W = np.zeros((self.N, self.N), dtype=float)
        for c, j in zip(coeffs, self.cfg.modes):
            W += c * self.Z[j]
        return W * self.aperture

    def diversity_phase(self, diversity: Diversity) -> np.ndarray:
        phase = np.zeros((self.N, self.N), dtype=float)
        for j, c in diversity.items():
            if j not in self.Z:
                self.Z[j] = zernike_mode(j, self.rho, self.theta, self.aperture)
            phase += float(c) * self.Z[j]
        return phase * self.aperture

def optical_transfer(model: FourierPDModel, coeffs: Sequence[float], diversity: Diversity) -> Tuple[np.ndarray, np.ndarray, np.ndarray]:
    phase = model.wavefront(coeffs) + model.diversity_phase(diversity)
    pupil = model.aperture * np.exp(1j * phase)
    h = np.fft.fftshift(np.fft.ifft2(np.fft.ifftshift(pupil)))
    psf = np.abs(h) ** 2
    energy = float(psf.sum())
    if energy <= 0:
        raise RuntimeError('La PSF tiene energía nula.')
    psf /= energy
    otf = np.fft.fft2(np.fft.ifftshift(psf))
    return (otf, psf, pupil)

def ideal_psf(model: FourierPDModel) -> np.ndarray:
    zero = np.zeros(len(model.cfg.modes), dtype=float)
    return optical_transfer(model, zero, {})[1]

def strehl_ratio(psf: np.ndarray, psf_ideal: np.ndarray) -> float:
    peak_ideal = float(np.max(psf_ideal))
    return float(np.max(psf) / peak_ideal) if peak_ideal > 0 else float('nan')
