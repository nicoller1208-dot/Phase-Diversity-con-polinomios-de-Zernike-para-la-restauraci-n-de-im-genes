from __future__ import annotations
from typing import List, Optional, Sequence
import numpy as np
from ..optics_final.system import Diversity, FourierPDModel, optical_transfer

def clean_image(model: FourierPDModel, true_coeffs: Sequence[float], diversity: Diversity) -> np.ndarray:
    otf, _, _ = optical_transfer(model, true_coeffs, diversity)
    return np.real(np.fft.ifft2(model.object_F * otf))

def make_noise_bank(N: int, K: int, seed: int) -> List[np.ndarray]:
    rng = np.random.default_rng(seed)
    return [rng.standard_normal((N, N)) for _ in range(K)]

def make_dataset(model: FourierPDModel, true_coeffs: Sequence[float], diversities: Sequence[Diversity], noise_sigma: float, noise_bank: Optional[Sequence[np.ndarray]]=None, seed: Optional[int]=None) -> List[np.ndarray]:
    if noise_sigma < 0:
        raise ValueError('noise_sigma debe ser >= 0.')
    K = len(diversities)
    if noise_bank is None:
        if seed is None:
            seed = model.cfg.main_seed
        noise_bank = make_noise_bank(model.N, K, int(seed))
    if len(noise_bank) < K:
        raise ValueError('noise_bank no contiene suficientes realizaciones.')
    images: List[np.ndarray] = []
    for k, div in enumerate(diversities):
        image = clean_image(model, true_coeffs, div)
        if noise_sigma > 0:
            image = image + noise_sigma * np.asarray(noise_bank[k], dtype=float)
        images.append(image)
    return images
