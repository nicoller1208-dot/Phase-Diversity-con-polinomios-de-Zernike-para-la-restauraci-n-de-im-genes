from __future__ import annotations
from typing import List, Optional, Sequence, Tuple
import warnings
import numpy as np
from scipy.optimize import minimize
from ..config import Config
from ..optics_final.system import Diversity, FourierPDModel, optical_transfer

def estimate_object_fourier(model: FourierPDModel, D: Sequence[np.ndarray], coeffs: Sequence[float], diversities: Sequence[Diversity], reg_object: float) -> Tuple[np.ndarray, List[np.ndarray]]:
    if len(D) != len(diversities):
        raise ValueError('D y diversities deben tener la misma longitud.')
    if reg_object < 0:
        raise ValueError('reg_object debe ser >= 0.')
    S = [optical_transfer(model, coeffs, div)[0] for div in diversities]
    denominator = np.zeros_like(S[0], dtype=float)
    numerator = np.zeros_like(D[0], dtype=complex)
    for s, d in zip(S, D):
        denominator += np.abs(s) ** 2
        numerator += np.conj(s) * d
    if reg_object > 0:
        Fhat = numerator / (denominator + reg_object)
    else:
        Fhat = np.zeros_like(numerator)
        valid = denominator > 1e-14
        Fhat[valid] = numerator[valid] / denominator[valid]
    return (Fhat, S)

def phase_diversity_objective(model: FourierPDModel, D: Sequence[np.ndarray], diversities: Sequence[Diversity], coeffs: Sequence[float], reg_object: float, reg_coeff: float, total_power: Optional[float]=None) -> float:
    if reg_coeff < 0:
        raise ValueError('reg_coeff debe ser >= 0.')
    if total_power is None:
        total_power = float(sum((np.sum(np.abs(d) ** 2) for d in D)))
    total_power = max(total_power, 1e-30)
    Fhat, S = estimate_object_fourier(model, D, coeffs, diversities, reg_object)
    residual = 0.0
    for d, s in zip(D, S):
        residual += float(np.sum(np.abs(d - Fhat * s) ** 2))
    residual /= total_power
    coeffs = np.asarray(coeffs, dtype=float)
    return float(residual + reg_coeff * np.sum(coeffs ** 2))

def generate_initial_guesses(cfg: Config, n_starts: int, seed: int, extra_starts: Optional[Sequence[Sequence[float]]]=None) -> List[np.ndarray]:
    if n_starts < 1:
        raise ValueError('n_starts debe ser >= 1.')
    J = len(cfg.modes)
    candidates: List[np.ndarray] = [np.zeros(J, dtype=float)]
    if extra_starts:
        for x0 in extra_starts:
            x0 = np.asarray(x0, dtype=float).reshape(-1)
            if x0.size == J:
                candidates.append(np.clip(x0, cfg.coeff_lower, cfg.coeff_upper))
    unique: List[np.ndarray] = []
    for g in candidates:
        if not any((np.allclose(g, u, atol=1e-12, rtol=0) for u in unique)):
            unique.append(g)
        if len(unique) >= n_starts:
            return unique[:n_starts]
    rng = np.random.default_rng(seed)
    span = cfg.coeff_upper - cfg.coeff_lower
    random_half_width = 0.3 * span
    center = 0.5 * (cfg.coeff_lower + cfg.coeff_upper)
    attempts = 0
    while len(unique) < n_starts:
        x0 = rng.uniform(center - random_half_width, center + random_half_width, size=J)
        x0 = np.clip(x0, cfg.coeff_lower, cfg.coeff_upper)
        if not any((np.allclose(x0, u, atol=1e-12, rtol=0) for u in unique)):
            unique.append(x0)
        attempts += 1
        if attempts > 10000:
            raise RuntimeError('No fue posible generar arranques únicos.')
    return unique

def estimate_pd(model: FourierPDModel, images: Sequence[np.ndarray], diversities: Sequence[Diversity], cfg: Config, n_starts: Optional[int]=None, maxiter: Optional[int]=None, seed: Optional[int]=None, extra_starts: Optional[Sequence[Sequence[float]]]=None) -> dict:
    if len(images) != len(diversities):
        raise ValueError('images y diversities deben tener la misma longitud.')
    n_starts = cfg.n_starts_main if n_starts is None else int(n_starts)
    maxiter = cfg.maxiter_main if maxiter is None else int(maxiter)
    seed = cfg.main_seed + 1000 if seed is None else int(seed)
    D = [np.fft.fft2(np.asarray(im, dtype=float)) for im in images]
    total_power = float(sum((np.sum(np.abs(d) ** 2) for d in D)))
    bounds = [(cfg.coeff_lower, cfg.coeff_upper)] * len(cfg.modes)
    guesses = generate_initial_guesses(cfg, n_starts, seed, extra_starts)
    candidates = []
    histories = []
    starts_summary = []
    for start_id, x0 in enumerate(guesses):
        history: List[float] = []

        def merit(c: np.ndarray) -> float:
            value = phase_diversity_objective(model=model, D=D, diversities=diversities, coeffs=c, reg_object=cfg.reg_object, reg_coeff=cfg.reg_coeff, total_power=total_power)
            history.append(value)
            return value
        result = minimize(merit, x0, method='Powell', bounds=bounds, options={'maxiter': maxiter, 'xtol': cfg.xtol, 'ftol': cfg.ftol, 'disp': False})
        candidates.append(result)
        histories.append(np.asarray(history, dtype=float))
        starts_summary.append({'start_id': start_id, 'x0': x0.copy(), 'fun': float(result.fun), 'coeffs': np.asarray(result.x, dtype=float).copy(), 'nfev': int(getattr(result, 'nfev', -1)), 'nit': int(getattr(result, 'nit', -1)), 'success': bool(result.success), 'message': str(result.message)})
    if not candidates:
        raise RuntimeError('La optimización no produjo resultados.')
    successful_idx = [i for i, r in enumerate(candidates) if bool(r.success)]
    warning_message = ''
    if successful_idx:
        best_idx = min(successful_idx, key=lambda i: float(candidates[i].fun))
    else:
        best_idx = min(range(len(candidates)), key=lambda i: float(candidates[i].fun))
        warning_message = 'Ningún arranque terminó con success=True; se conserva el menor valor de la función objetivo.'
        warnings.warn(warning_message, RuntimeWarning)
    best_result = candidates[best_idx]
    best_history = histories[best_idx]
    coeffs = np.asarray(best_result.x, dtype=float)
    Fhat, _ = estimate_object_fourier(model, D, coeffs, diversities, cfg.reg_object)
    restored_raw = np.real(np.fft.ifft2(Fhat))
    restored = np.clip(restored_raw, 0.0, 1.0)
    return {'coeffs': coeffs, 'restored': restored, 'restored_raw': restored_raw, 'objective': float(best_result.fun), 'nfev': int(getattr(best_result, 'nfev', -1)), 'nit': int(getattr(best_result, 'nit', -1)), 'success': bool(best_result.success), 'message': str(best_result.message), 'optimizer_warning': warning_message, 'history': best_history, 'starts': starts_summary, 'best_start_id': int(best_idx)}
