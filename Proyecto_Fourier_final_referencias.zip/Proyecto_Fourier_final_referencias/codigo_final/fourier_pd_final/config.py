from __future__ import annotations
from dataclasses import dataclass
from typing import Optional, Tuple

@dataclass(frozen=True)
class Config:
    N: int = 128
    object_path: Optional[str] = None
    modes: Tuple[int, ...] = (4, 5, 7, 8)
    true_coeffs: Tuple[float, ...] = (0.55, -0.38, 0.26, -0.22)
    d4: float = 0.9
    d5_fallback: float = 3.0
    noise_sigma: float = 0.003
    main_seed: int = 42
    reg_object: float = 0.002
    reg_coeff: float = 0.0
    coeff_lower: float = -1.5
    coeff_upper: float = 1.5
    n_starts_main: int = 3
    n_starts_selection: int = 1
    n_starts_monte_carlo: int = 1
    n_starts_sensitivity: int = 1
    n_starts_random: int = 1
    maxiter_main: int = 140
    maxiter_fast: int = 60
    xtol: float = 0.002
    ftol: float = 1e-07
    run_d5_selection: bool = True
    d5_min: float = 0.0
    d5_max: float = 5.0
    d5_points: int = 6
    selection_seeds: Tuple[int, ...] = (101, 102, 103)
    selection_psnr_tolerance_db: float = 0.0
    run_monte_carlo: bool = True
    evaluation_seeds: Tuple[int, ...] = tuple(range(201, 207))
    run_aberration_cases: bool = True
    aberration_case_seeds: Tuple[int, ...] = (401, 402, 403, 404)
    n_starts_cases: int = 1
    maxiter_cases: int = 70
    run_random_aberrations: bool = True
    n_random_aberrations: int = 20
    random_aberration_seed: int = 500
    random_aberration_noise_seeds: Tuple[int, ...] = tuple(range(701, 721))
    maxiter_random: int = 70
    run_regularization_sensitivity: bool = True
    sensitivity_seed: int = 301
    reg_object_values: Tuple[float, ...] = (0.001, 0.004)
    reg_coeff_values: Tuple[float, ...] = (0.0, 0.0002)
    run_validations: bool = True
    run_optimizer_validation: bool = True
    stop_on_validation_failure: bool = True
    noiseless_rmse_tolerance: float = 0.01
    output_folder: str = 'salida_fourier_final'

    def __post_init__(self) -> None:
        if len(self.modes) != len(self.true_coeffs):
            raise ValueError('modes y true_coeffs deben tener la misma longitud.')
        if self.N < 32:
            raise ValueError('N debe ser al menos 32.')
        if self.noise_sigma < 0:
            raise ValueError('noise_sigma no puede ser negativo.')
        if self.reg_object < 0 or self.reg_coeff < 0:
            raise ValueError('Las regularizaciones no pueden ser negativas.')
        if self.coeff_lower >= self.coeff_upper:
            raise ValueError('Los límites de coeficientes no son válidos.')
        starts = (self.n_starts_main, self.n_starts_selection, self.n_starts_monte_carlo, self.n_starts_sensitivity, self.n_starts_cases, self.n_starts_random)
        if any((v < 1 for v in starts)):
            raise ValueError('El número de inicializaciones debe ser >= 1.')
        if self.d5_points < 2 or self.d5_min >= self.d5_max:
            raise ValueError('El barrido de D5 no es válido.')
        if set(self.selection_seeds) & set(self.evaluation_seeds):
            raise ValueError('selection_seeds y evaluation_seeds deben ser disjuntas.')
        used_main = set(self.selection_seeds) | set(self.evaluation_seeds)
        if self.sensitivity_seed in used_main:
            raise ValueError('sensitivity_seed debe ser independiente de selección y evaluación.')
        if set(self.aberration_case_seeds) & (used_main | {self.sensitivity_seed}):
            raise ValueError('aberration_case_seeds deben ser independientes de las demás semillas.')
        if self.maxiter_cases < 1:
            raise ValueError('maxiter_cases debe ser >= 1.')
        if self.n_random_aberrations < 1:
            raise ValueError('n_random_aberrations debe ser >= 1.')
        if len(self.random_aberration_noise_seeds) != self.n_random_aberrations:
            raise ValueError('random_aberration_noise_seeds debe tener exactamente n_random_aberrations elementos.')
        reserved = used_main | {self.sensitivity_seed} | set(self.aberration_case_seeds)
        if set(self.random_aberration_noise_seeds) & reserved:
            raise ValueError('Las semillas del estudio aleatorio deben ser independientes de selección, evaluación, sensibilidad y casos manuales.')
        if self.maxiter_random < 1:
            raise ValueError('maxiter_random debe ser >= 1.')
