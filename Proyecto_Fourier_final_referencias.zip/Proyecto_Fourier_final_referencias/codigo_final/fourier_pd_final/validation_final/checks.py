from __future__ import annotations
from dataclasses import replace
from typing import List, Tuple
import numpy as np
from ..algorithms_final.phase_diversity import estimate_object_fourier, estimate_pd
from ..analysis_final.metrics import coefficient_rmse
from ..config import Config
from ..optics_final.system import FourierPDModel, optical_transfer
from ..optics_final.zernike import ansi_nm
from ..simulation_final.data import make_dataset

def validation_record(name: str, passed: bool, value: str, criterion: str) -> dict:
    return {'Prueba': name, 'Estado': 'PASS' if passed else 'FAIL', 'Valor': value, 'Criterio': criterion}

def validate_ansi_indices() -> dict:
    expected = {0: (0, 0), 1: (1, -1), 2: (1, 1), 3: (2, -2), 4: (2, 0), 5: (2, 2), 6: (3, -3), 7: (3, -1), 8: (3, 1), 9: (3, 3)}
    obtained = {j: ansi_nm(j) for j in expected}
    return validation_record('Índices ANSI/OSA', obtained == expected, str(obtained), 'j=0..9 deben corresponder a los pares ANSI/OSA esperados')

def validate_zernike_orthonormality(model: FourierPDModel) -> Tuple[dict, np.ndarray]:
    modes = list(model.cfg.modes)
    G = np.zeros((len(modes), len(modes)), dtype=float)
    for a, ja in enumerate(modes):
        for b, jb in enumerate(modes):
            G[a, b] = np.sum(model.Z[ja] * model.Z[jb]) * model.dx ** 2 / np.pi
    diag_error = float(np.max(np.abs(np.diag(G) - 1.0)))
    off = G - np.diag(np.diag(G))
    off_error = float(np.max(np.abs(off)))
    passed = diag_error < 0.025 and off_error < 0.015
    return (validation_record('Ortonormalidad de Zernike', passed, f'error_diag={diag_error:.3e}; error_fuera_diag={off_error:.3e}', 'error diagonal < 2.5e-2 y fuera de diagonal < 1.5e-2'), G)

def validate_pupil_psf_otf(model: FourierPDModel) -> List[dict]:
    zero = np.zeros(len(model.cfg.modes), dtype=float)
    otf, psf, pupil = optical_transfer(model, zero, {})
    mask_in = model.aperture > 0
    mask_out = ~mask_in
    mod_in_err = float(np.max(np.abs(np.abs(pupil[mask_in]) - 1.0)))
    max_out = float(np.max(np.abs(pupil[mask_out]))) if np.any(mask_out) else 0.0
    pupil_pass = mod_in_err < 1e-12 and max_out < 1e-12
    psf_min = float(np.min(psf))
    psf_sum_error = abs(float(psf.sum()) - 1.0)
    psf_pass = psf_min >= -1e-15 and psf_sum_error < 1e-12
    dc_error = abs(otf[0, 0] - 1.0)
    idx = -np.arange(model.N) % model.N
    otf_negative = otf[np.ix_(idx, idx)]
    hermitian_error = float(np.max(np.abs(otf_negative - np.conj(otf))))
    otf_pass = abs(dc_error) < 1e-12 and hermitian_error < 1e-10
    return [validation_record('Función de pupila', pupil_pass, f'err_mod_in={mod_in_err:.3e}; max_out={max_out:.3e}', '|P|=1 dentro de la apertura y P=0 fuera'), validation_record('Normalización de PSF', psf_pass, f'min={psf_min:.3e}; |sum-1|={psf_sum_error:.3e}', 'PSF >= 0 y suma(PSF)=1'), validation_record('Propiedades de OTF', otf_pass, f'|OTF(0)-1|={abs(dc_error):.3e}; err_Herm={hermitian_error:.3e}', 'OTF(0)=1 y simetría Hermítica')]

def validate_convolution_theorem() -> dict:
    rng = np.random.default_rng(123)
    n = 8
    f = rng.normal(size=(n, n))
    h = rng.normal(size=(n, n))
    y_fft = np.real(np.fft.ifft2(np.fft.fft2(f) * np.fft.fft2(h)))
    y_direct = np.zeros_like(f)
    for i in range(n):
        for j in range(n):
            acc = 0.0
            for p in range(n):
                for q in range(n):
                    acc += f[p, q] * h[(i - p) % n, (j - q) % n]
            y_direct[i, j] = acc
    error = float(np.max(np.abs(y_fft - y_direct)))
    return validation_record('Teorema de convolución', error < 1e-10, f'error_max={error:.3e}', 'convolución circular directa = producto en Fourier, error < 1e-10')

def validate_closed_form_object(model: FourierPDModel, cfg: Config) -> dict:
    diversities = [{}, {4: cfg.d4}]
    true_coeffs = np.asarray(cfg.true_coeffs, dtype=float)
    images = make_dataset(model, true_coeffs, diversities, 0.0, seed=cfg.main_seed)
    D = [np.fft.fft2(im) for im in images]
    Fhat, S = estimate_object_fourier(model, D, true_coeffs, diversities, 0.0)
    numerator = 0.0
    denominator = 0.0
    for d, s in zip(D, S):
        numerator += float(np.sum(np.abs(d - Fhat * s) ** 2))
        denominator += float(np.sum(np.abs(d) ** 2))
    rel_residual = numerator / max(denominator, 1e-30)
    return validation_record('Estimación cerrada del objeto', rel_residual < 1e-10, f'residuo_rel={rel_residual:.3e}', 'con C verdadero y sin ruido, residuo relativo < 1e-10')

def validate_noiseless_optimizer(cfg: Config) -> dict:
    small_cfg = replace(cfg, N=96, noise_sigma=0.0, reg_object=1e-10, reg_coeff=1e-10, n_starts_main=4, maxiter_main=220, run_d5_selection=False, run_monte_carlo=False, run_regularization_sensitivity=False, run_validations=False)
    model = FourierPDModel(small_cfg)
    diversities = [{}, {4: small_cfg.d4, 5: small_cfg.d5_fallback}]
    images = make_dataset(model, small_cfg.true_coeffs, diversities, 0.0, seed=small_cfg.main_seed)
    result = estimate_pd(model, images, diversities, small_cfg, n_starts=4, maxiter=220, seed=771, extra_starts=[small_cfg.true_coeffs])
    rmse = coefficient_rmse(result['coeffs'], small_cfg.true_coeffs)
    tol = cfg.noiseless_rmse_tolerance
    return validation_record('Recuperación completa sin ruido', rmse < tol, f"RMSE_C={rmse:.6f} rad; C_est={np.round(result['coeffs'], 5)}", f'RMSE_C < {tol:.4f} rad en la prueba de integración')

def run_validations(model: FourierPDModel, cfg: Config) -> Tuple[List[dict], np.ndarray]:
    records: List[dict] = [validate_ansi_indices()]
    rec_ortho, gram = validate_zernike_orthonormality(model)
    records.append(rec_ortho)
    records.extend(validate_pupil_psf_otf(model))
    records.append(validate_convolution_theorem())
    records.append(validate_closed_form_object(model, cfg))
    if cfg.run_optimizer_validation:
        records.append(validate_noiseless_optimizer(cfg))
    return (records, gram)
