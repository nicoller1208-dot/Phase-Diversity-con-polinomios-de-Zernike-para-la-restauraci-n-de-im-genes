from __future__ import annotations
from dataclasses import asdict
from pathlib import Path
from typing import Sequence, Tuple
import csv
import json
import numpy as np
from ..config import Config
from ..optics_final.system import FourierPDModel

def ensure_output_dirs(root: Path, cfg: Config) -> Tuple[Path, Path]:
    output = root / cfg.output_folder
    figures = output / 'figuras'
    output.mkdir(parents=True, exist_ok=True)
    figures.mkdir(parents=True, exist_ok=True)
    return (output, figures)

def save_config(cfg: Config, output: Path) -> None:
    with open(output / 'configuracion.json', 'w', encoding='utf-8') as f:
        json.dump(asdict(cfg), f, ensure_ascii=False, indent=2)

def save_runtime_info(selected_d5: float, selection_rule: str, output: Path) -> None:
    with open(output / 'configuracion_ejecucion.json', 'w', encoding='utf-8') as f:
        json.dump({'D5_seleccionado_rad': float(selected_d5), 'criterio_seleccion_D5': selection_rule}, f, ensure_ascii=False, indent=2)

def write_dict_csv(path: Path, rows: Sequence[dict]) -> None:
    if not rows:
        return
    fields = []
    seen = set()
    for row in rows:
        for key in row.keys():
            if key not in seen:
                fields.append(key)
                seen.add(key)
    with open(path, 'w', newline='', encoding='utf-8') as f:
        writer = csv.DictWriter(f, fieldnames=fields, extrasaction='ignore')
        writer.writeheader()
        for row in rows:
            writer.writerow(row)

def save_main_results(model: FourierPDModel, main: dict, output: Path) -> None:
    true_coeffs = np.asarray(model.cfg.true_coeffs)
    conv = main['result_conv']['coeffs']
    ext = main['result_ext']['coeffs']
    coeff_rows = []
    for j, t, c, e in zip(model.cfg.modes, true_coeffs, conv, ext):
        coeff_rows.append({'Modo': f'Z{j}', 'Teorico_rad': float(t), 'Estimado_PD_conv_rad': float(c), 'Error_abs_PD_conv_rad': float(abs(c - t)), 'Estimado_PD_ext_rad': float(e), 'Error_abs_PD_ext_rad': float(abs(e - t))})
    write_dict_csv(output / 'resultados_coeficientes.csv', coeff_rows)
    metric_rows = []
    for method, met, result in [('PD convencional', main['metrics_conv'], main['result_conv']), ('PD extendida', main['metrics_ext'], main['result_ext'])]:
        metric_rows.append({'Metodo': method, 'D5_seleccionado_rad': 0.0 if method == 'PD convencional' else main['selected_d5'], 'RMSE_C_rad': met['RMSE_C'], 'RMSE_W_rad': met['RMSE_W'], 'RMSE_imagen': met['RMSE_image'], 'PSNR_dB': met['PSNR'], 'SSIM': met['SSIM'], 'Strehl_true': met['Strehl_true'], 'Strehl_estimado': met['Strehl_est'], 'Funcion_objetivo': result['objective'], 'nfev_mejor_arranque': result['nfev'], 'nit_mejor_arranque': result['nit'], 'success': result['success'], 'message': result['message'], 'best_start_id': result['best_start_id'], 'numero_arranques': len(result['starts'])})
    write_dict_csv(output / 'resultados_metricas.csv', metric_rows)
    start_rows = []
    for method, result in [('PD convencional', main['result_conv']), ('PD extendida', main['result_ext'])]:
        for row in result['starts']:
            start_rows.append({'Metodo': method, 'start_id': row['start_id'], 'x0': np.array2string(row['x0'], precision=5, separator=';'), 'fun': row['fun'], 'coeffs': np.array2string(row['coeffs'], precision=5, separator=';'), 'nfev': row['nfev'], 'nit': row['nit'], 'success': row['success'], 'message': row['message']})
    write_dict_csv(output / 'resultados_multistart.csv', start_rows)
