from __future__ import annotations
from dataclasses import replace
from typing import Dict, List, Optional, Sequence, Tuple
import numpy as np
from ..algorithms_final.phase_diversity import estimate_pd
from ..config import Config
from ..optics_final.system import Diversity, FourierPDModel
from ..simulation_final.data import make_dataset, make_noise_bank
from .metrics import result_metrics

def conventional_diversities(cfg: Config) -> List[Diversity]:
    return [{}, {4: cfg.d4}]

def extended_diversities(cfg: Config, d5: Optional[float]=None) -> List[Diversity]:
    if d5 is None:
        d5 = cfg.d5_fallback
    return [{}, {4: cfg.d4, 5: float(d5)}]

def _mean_std(values: Sequence[float]) -> Tuple[float, float]:
    arr = np.asarray(values, dtype=float)
    mean = float(np.mean(arr))
    std = float(np.std(arr, ddof=1)) if arr.size > 1 else 0.0
    return (mean, std)

def select_d5(model: FourierPDModel, cfg: Config) -> dict:
    true_coeffs = np.asarray(cfg.true_coeffs, dtype=float)
    d5_values = np.linspace(cfg.d5_min, cfg.d5_max, cfg.d5_points)
    raw_rows: List[dict] = []
    conv_metrics_by_seed: Dict[int, dict] = {}
    for seed in cfg.selection_seeds:
        noise_bank = make_noise_bank(model.N, K=2, seed=int(seed))
        div_conv = conventional_diversities(cfg)
        images_conv = make_dataset(model, true_coeffs, div_conv, cfg.noise_sigma, noise_bank=noise_bank)
        result_conv = estimate_pd(model, images_conv, div_conv, cfg, n_starts=cfg.n_starts_selection, maxiter=cfg.maxiter_fast, seed=10000 + int(seed))
        conv_metrics_by_seed[int(seed)] = result_metrics(model, result_conv, true_coeffs)
        warm_start = None
        for i, d5 in enumerate(d5_values):
            div_ext = extended_diversities(cfg, float(d5))
            images_ext = make_dataset(model, true_coeffs, div_ext, cfg.noise_sigma, noise_bank=noise_bank)
            extra = [warm_start] if warm_start is not None else None
            result_ext = estimate_pd(model, images_ext, div_ext, cfg, n_starts=cfg.n_starts_selection, maxiter=cfg.maxiter_fast, seed=20000 + 100 * int(seed) + i, extra_starts=extra)
            met = result_metrics(model, result_ext, true_coeffs)
            warm_start = result_ext['coeffs'].copy()
            raw_rows.append({'seed': int(seed), 'D5_rad': float(d5), 'RMSE_C_rad': met['RMSE_C'], 'RMSE_W_rad': met['RMSE_W'], 'PSNR_dB': met['PSNR'], 'SSIM': met['SSIM'], 'objective': result_ext['objective'], 'optimizer_success': result_ext['success']})
        print(f'  Selección D5: seed={seed} completada')
    conv_rmse_c_mean, conv_rmse_c_std = _mean_std([m['RMSE_C'] for m in conv_metrics_by_seed.values()])
    conv_psnr_mean, conv_psnr_std = _mean_std([m['PSNR'] for m in conv_metrics_by_seed.values()])
    summary_rows: List[dict] = []
    for d5 in d5_values:
        subset = [r for r in raw_rows if np.isclose(r['D5_rad'], d5)]
        rmse_c_mean, rmse_c_std = _mean_std([r['RMSE_C_rad'] for r in subset])
        rmse_w_mean, rmse_w_std = _mean_std([r['RMSE_W_rad'] for r in subset])
        psnr_mean, psnr_std = _mean_std([r['PSNR_dB'] for r in subset])
        ssim_mean, ssim_std = _mean_std([r['SSIM'] for r in subset])
        feasible = psnr_mean >= conv_psnr_mean - cfg.selection_psnr_tolerance_db
        improves_rmse = rmse_c_mean < conv_rmse_c_mean
        improves_psnr = psnr_mean > conv_psnr_mean
        dominant = improves_rmse and improves_psnr
        summary_rows.append({'D5_rad': float(d5), 'RMSE_C_mean_rad': rmse_c_mean, 'RMSE_C_std_rad': rmse_c_std, 'RMSE_W_mean_rad': rmse_w_mean, 'RMSE_W_std_rad': rmse_w_std, 'PSNR_mean_dB': psnr_mean, 'PSNR_std_dB': psnr_std, 'SSIM_mean': ssim_mean, 'SSIM_std': ssim_std, 'Conv_RMSE_C_mean_rad': conv_rmse_c_mean, 'Conv_RMSE_C_std_rad': conv_rmse_c_std, 'Conv_PSNR_mean_dB': conv_psnr_mean, 'Conv_PSNR_std_dB': conv_psnr_std, 'Mejora_RMSE_vs_conv': bool(improves_rmse), 'Mejora_PSNR_vs_conv': bool(improves_psnr), 'Mejora_ambas_vs_conv': bool(dominant), 'Factible_por_PSNR': bool(feasible)})
    candidate_rows = [r for r in summary_rows if r['D5_rad'] > 0]
    dominant_rows = [r for r in candidate_rows if r['Mejora_ambas_vs_conv']]
    if dominant_rows:
        selected = min(dominant_rows, key=lambda r: (r['RMSE_C_mean_rad'], -r['PSNR_mean_dB']))
        selection_status = 'mejora_simultanea'
        rule = 'Se escogió el D5 con menor RMSE_C medio entre los candidatos que mejoraron simultáneamente RMSE_C y PSNR frente a PD convencional.'
    else:
        feasible_rows = [r for r in candidate_rows if r['Factible_por_PSNR']]
        pool = feasible_rows if feasible_rows else candidate_rows
        selected = min(pool, key=lambda r: (r['RMSE_C_mean_rad'], -r['PSNR_mean_dB']))
        selection_status = 'compromiso_sin_mejora_simultanea'
        rule = f'Ningún D5 mejoró simultáneamente RMSE_C y PSNR frente a PD convencional. Se escogió como compromiso el menor RMSE_C medio entre los candidatos con PSNR medio >= PSNR convencional - {cfg.selection_psnr_tolerance_db:.3f} dB.'
    return {'selected_d5': float(selected['D5_rad']), 'selection_status': selection_status, 'selection_rule': rule, 'summary_rows': summary_rows, 'raw_rows': raw_rows, 'conv_baseline': {'RMSE_C_mean_rad': conv_rmse_c_mean, 'RMSE_C_std_rad': conv_rmse_c_std, 'PSNR_mean_dB': conv_psnr_mean, 'PSNR_std_dB': conv_psnr_std}}

def run_main_comparison(model: FourierPDModel, cfg: Config, selected_d5: float, seed: Optional[int]=None) -> dict:
    if seed is None:
        seed = cfg.main_seed
    true_coeffs = np.asarray(cfg.true_coeffs, dtype=float)
    div_conv = conventional_diversities(cfg)
    div_ext = extended_diversities(cfg, selected_d5)
    noise_bank = make_noise_bank(model.N, K=2, seed=int(seed))
    images_conv = make_dataset(model, true_coeffs, div_conv, cfg.noise_sigma, noise_bank=noise_bank)
    images_ext = make_dataset(model, true_coeffs, div_ext, cfg.noise_sigma, noise_bank=noise_bank)
    result_conv = estimate_pd(model, images_conv, div_conv, cfg, n_starts=cfg.n_starts_main, maxiter=cfg.maxiter_main, seed=cfg.main_seed + 100)
    result_ext = estimate_pd(model, images_ext, div_ext, cfg, n_starts=cfg.n_starts_main, maxiter=cfg.maxiter_main, seed=cfg.main_seed + 200)
    return {'selected_d5': float(selected_d5), 'seed': int(seed), 'div_conv': div_conv, 'div_ext': div_ext, 'images_conv': images_conv, 'images_ext': images_ext, 'result_conv': result_conv, 'result_ext': result_ext, 'metrics_conv': result_metrics(model, result_conv, true_coeffs), 'metrics_ext': result_metrics(model, result_ext, true_coeffs)}

def run_monte_carlo(model: FourierPDModel, cfg: Config, selected_d5: float, warm_main: Optional[dict]=None) -> List[dict]:
    true_coeffs = np.asarray(cfg.true_coeffs, dtype=float)
    div_conv = conventional_diversities(cfg)
    div_ext = extended_diversities(cfg, selected_d5)
    rows: List[dict] = []
    warm_conv = None if warm_main is None else warm_main['result_conv']['coeffs']
    warm_ext = None if warm_main is None else warm_main['result_ext']['coeffs']
    for seed in cfg.evaluation_seeds:
        noise_bank = make_noise_bank(model.N, K=2, seed=int(seed))
        images_conv = make_dataset(model, true_coeffs, div_conv, cfg.noise_sigma, noise_bank=noise_bank)
        images_ext = make_dataset(model, true_coeffs, div_ext, cfg.noise_sigma, noise_bank=noise_bank)
        result_conv = estimate_pd(model, images_conv, div_conv, cfg, n_starts=cfg.n_starts_monte_carlo, maxiter=cfg.maxiter_fast, seed=30000 + int(seed), extra_starts=[warm_conv] if warm_conv is not None else None)
        result_ext = estimate_pd(model, images_ext, div_ext, cfg, n_starts=cfg.n_starts_monte_carlo, maxiter=cfg.maxiter_fast, seed=40000 + int(seed), extra_starts=[warm_ext] if warm_ext is not None else None)
        for method, result in [('PD convencional', result_conv), ('PD extendida', result_ext)]:
            met = result_metrics(model, result, true_coeffs)
            rows.append({'seed': int(seed), 'Metodo': method, 'D5_rad': 0.0 if method == 'PD convencional' else float(selected_d5), 'RMSE_C_rad': met['RMSE_C'], 'RMSE_W_rad': met['RMSE_W'], 'RMSE_imagen': met['RMSE_image'], 'PSNR_dB': met['PSNR'], 'SSIM': met['SSIM'], 'Strehl_estimado': met['Strehl_est'], 'objective': result['objective'], 'optimizer_success': result['success']})
        print(f'  Monte Carlo evaluación: seed={seed} completada')
    return rows

def summarize_monte_carlo(rows: Sequence[dict]) -> List[dict]:
    methods = ['PD convencional', 'PD extendida']
    summary: List[dict] = []
    for method in methods:
        subset = [r for r in rows if r['Metodo'] == method]
        row = {'Metodo': method, 'N_semillas': len(subset)}
        for key, outname in [('RMSE_C_rad', 'RMSE_C'), ('RMSE_W_rad', 'RMSE_W'), ('PSNR_dB', 'PSNR'), ('SSIM', 'SSIM')]:
            mean, std = _mean_std([r[key] for r in subset])
            row[f'{outname}_mean'] = mean
            row[f'{outname}_std'] = std
        summary.append(row)
    seeds = sorted({int(r['seed']) for r in rows})
    diffs_rmse = []
    diffs_psnr = []
    wins_rmse = 0
    wins_psnr = 0
    for seed in seeds:
        conv = next((r for r in rows if r['seed'] == seed and r['Metodo'] == 'PD convencional'))
        ext = next((r for r in rows if r['seed'] == seed and r['Metodo'] == 'PD extendida'))
        dr = ext['RMSE_C_rad'] - conv['RMSE_C_rad']
        dp = ext['PSNR_dB'] - conv['PSNR_dB']
        diffs_rmse.append(dr)
        diffs_psnr.append(dp)
        wins_rmse += int(dr < 0)
        wins_psnr += int(dp > 0)
    mean_dr, std_dr = _mean_std(diffs_rmse)
    mean_dp, std_dp = _mean_std(diffs_psnr)
    summary.append({'Metodo': 'Diferencia pareada ext-conv', 'N_semillas': len(seeds), 'RMSE_C_mean': mean_dr, 'RMSE_C_std': std_dr, 'RMSE_W_mean': float('nan'), 'RMSE_W_std': float('nan'), 'PSNR_mean': mean_dp, 'PSNR_std': std_dp, 'SSIM_mean': float('nan'), 'SSIM_std': float('nan'), 'Victorias_RMSE_ext': wins_rmse, 'Victorias_PSNR_ext': wins_psnr})
    return summary

def run_regularization_sensitivity(model: FourierPDModel, cfg: Config, selected_d5: float) -> List[dict]:
    true_coeffs = np.asarray(cfg.true_coeffs, dtype=float)
    noise_bank = make_noise_bank(model.N, K=2, seed=cfg.sensitivity_seed)
    rows: List[dict] = []
    for ro in cfg.reg_object_values:
        for rc in cfg.reg_coeff_values:
            cfg2 = replace(cfg, reg_object=float(ro), reg_coeff=float(rc))
            method_results = {}
            for method, divs in [('PD convencional', conventional_diversities(cfg2)), ('PD extendida', extended_diversities(cfg2, selected_d5))]:
                images = make_dataset(model, true_coeffs, divs, cfg2.noise_sigma, noise_bank=noise_bank)
                result = estimate_pd(model, images, divs, cfg2, n_starts=cfg2.n_starts_sensitivity, maxiter=cfg2.maxiter_fast, seed=50000 + int(round(ro * 1000000.0)) + int(round(rc * 1000000.0)))
                method_results[method] = result_metrics(model, result, true_coeffs)
            conv = method_results['PD convencional']
            ext = method_results['PD extendida']
            rows.append({'reg_object': float(ro), 'reg_coeff': float(rc), 'RMSE_C_conv_rad': conv['RMSE_C'], 'RMSE_C_ext_rad': ext['RMSE_C'], 'Delta_RMSE_C_ext_minus_conv': ext['RMSE_C'] - conv['RMSE_C'], 'PSNR_conv_dB': conv['PSNR'], 'PSNR_ext_dB': ext['PSNR'], 'Delta_PSNR_ext_minus_conv_dB': ext['PSNR'] - conv['PSNR']})
            print(f'  Sensibilidad regularización: λF={ro:g}, λC={rc:g}')
    return rows
