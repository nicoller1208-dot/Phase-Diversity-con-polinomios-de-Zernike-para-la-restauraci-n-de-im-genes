from __future__ import annotations
from typing import List, Sequence, Tuple
import numpy as np
from ..algorithms_final.phase_diversity import estimate_pd
from ..config import Config
from ..optics_final.system import FourierPDModel
from ..simulation_final.data import make_dataset, make_noise_bank
from .experiments import conventional_diversities, extended_diversities
from .metrics import result_metrics

def _mean_std(values: Sequence[float]) -> Tuple[float, float]:
    arr = np.asarray(values, dtype=float)
    return (float(np.mean(arr)), float(np.std(arr, ddof=1)) if arr.size > 1 else 0.0)

def generate_random_coefficients(cfg: Config) -> np.ndarray:
    rng = np.random.default_rng(cfg.random_aberration_seed)
    target_norm = float(np.linalg.norm(np.asarray(cfg.true_coeffs, dtype=float)))
    J = len(cfg.modes)
    out = []
    while len(out) < cfg.n_random_aberrations:
        vec = rng.standard_normal(J)
        norm = float(np.linalg.norm(vec))
        if norm <= 1e-14:
            continue
        coeffs = vec * (target_norm / norm)
        if np.any(coeffs < cfg.coeff_lower) or np.any(coeffs > cfg.coeff_upper):
            continue
        out.append(coeffs)
    return np.asarray(out, dtype=float)

def run_random_aberration_study(model: FourierPDModel, cfg: Config, selected_d5: float) -> dict:
    coeff_matrix = generate_random_coefficients(cfg)
    div_conv = conventional_diversities(cfg)
    div_ext = extended_diversities(cfg, selected_d5)
    rows: List[dict] = []
    paired_rows: List[dict] = []
    for i, (true_coeffs, noise_seed) in enumerate(zip(coeff_matrix, cfg.random_aberration_noise_seeds), start=1):
        case_name = f'Aleatorio_{i:02d}'
        noise_bank = make_noise_bank(model.N, K=2, seed=int(noise_seed))
        images_conv = make_dataset(model, true_coeffs, div_conv, cfg.noise_sigma, noise_bank=noise_bank)
        images_ext = make_dataset(model, true_coeffs, div_ext, cfg.noise_sigma, noise_bank=noise_bank)
        result_conv = estimate_pd(model, images_conv, div_conv, cfg, n_starts=cfg.n_starts_random, maxiter=cfg.maxiter_random, seed=70000 + i)
        result_ext = estimate_pd(model, images_ext, div_ext, cfg, n_starts=cfg.n_starts_random, maxiter=cfg.maxiter_random, seed=80000 + i)
        met_conv = result_metrics(model, result_conv, true_coeffs)
        met_ext = result_metrics(model, result_ext, true_coeffs)
        coeff_text = ';'.join((f'{v:.8f}' for v in true_coeffs))
        for method, result, met in [('PD convencional', result_conv, met_conv), ('PD extendida', result_ext, met_ext)]:
            rows.append({'Caso': case_name, 'Indice': i, 'Modos': ';'.join((f'Z{j}' for j in cfg.modes)), 'Coeficientes_teoricos_rad': coeff_text, 'Norma_coeficientes_rad': float(np.linalg.norm(true_coeffs)), 'noise_seed': int(noise_seed), 'Metodo': method, 'D5_rad': 0.0 if method == 'PD convencional' else float(selected_d5), 'RMSE_C_rad': met['RMSE_C'], 'RMSE_W_rad': met['RMSE_W'], 'RMSE_imagen': met['RMSE_image'], 'PSNR_dB': met['PSNR'], 'SSIM': met['SSIM'], 'Strehl_estimado': met['Strehl_est'], 'Funcion_objetivo': result['objective'], 'optimizer_success': result['success'], 'coeficientes_estimados_rad': ';'.join((f'{v:.8f}' for v in result['coeffs']))})
        delta_rmse = float(met_ext['RMSE_C'] - met_conv['RMSE_C'])
        delta_psnr = float(met_ext['PSNR'] - met_conv['PSNR'])
        delta_ssim = float(met_ext['SSIM'] - met_conv['SSIM'])
        paired_rows.append({'Caso': case_name, 'Indice': i, 'noise_seed': int(noise_seed), 'Delta_RMSE_C_ext_minus_conv_rad': delta_rmse, 'Delta_PSNR_ext_minus_conv_dB': delta_psnr, 'Delta_SSIM_ext_minus_conv': delta_ssim, 'Mejora_RMSE_ext': bool(delta_rmse < 0), 'Mejora_PSNR_ext': bool(delta_psnr > 0), 'Mejora_SSIM_ext': bool(delta_ssim > 0), 'Mejora_ambas_RMSE_y_PSNR': bool(delta_rmse < 0 and delta_psnr > 0)})
        print(f'  Aleatorio {i:02d}/{cfg.n_random_aberrations}: ΔRMSE={delta_rmse:+.5e}, ΔPSNR={delta_psnr:+.3f} dB')
    conv_rows = [r for r in rows if r['Metodo'] == 'PD convencional']
    ext_rows = [r for r in rows if r['Metodo'] == 'PD extendida']
    summary = {'N_casos': cfg.n_random_aberrations, 'Modos': ';'.join((f'Z{j}' for j in cfg.modes)), 'Norma_objetivo_rad': float(np.linalg.norm(np.asarray(cfg.true_coeffs))), 'Semilla_coeficientes': int(cfg.random_aberration_seed), 'D5_rad': float(selected_d5), 'RMSE_C_conv_mean': _mean_std([r['RMSE_C_rad'] for r in conv_rows])[0], 'RMSE_C_conv_std': _mean_std([r['RMSE_C_rad'] for r in conv_rows])[1], 'RMSE_C_ext_mean': _mean_std([r['RMSE_C_rad'] for r in ext_rows])[0], 'RMSE_C_ext_std': _mean_std([r['RMSE_C_rad'] for r in ext_rows])[1], 'PSNR_conv_mean': _mean_std([r['PSNR_dB'] for r in conv_rows])[0], 'PSNR_conv_std': _mean_std([r['PSNR_dB'] for r in conv_rows])[1], 'PSNR_ext_mean': _mean_std([r['PSNR_dB'] for r in ext_rows])[0], 'PSNR_ext_std': _mean_std([r['PSNR_dB'] for r in ext_rows])[1], 'Victorias_RMSE_ext': int(sum((r['Mejora_RMSE_ext'] for r in paired_rows))), 'Victorias_PSNR_ext': int(sum((r['Mejora_PSNR_ext'] for r in paired_rows))), 'Victorias_SSIM_ext': int(sum((r['Mejora_SSIM_ext'] for r in paired_rows))), 'Victorias_ambas_ext': int(sum((r['Mejora_ambas_RMSE_y_PSNR'] for r in paired_rows)))}
    summary['Porcentaje_RMSE_ext'] = 100.0 * summary['Victorias_RMSE_ext'] / cfg.n_random_aberrations
    summary['Porcentaje_PSNR_ext'] = 100.0 * summary['Victorias_PSNR_ext'] / cfg.n_random_aberrations
    summary['Porcentaje_ambas_ext'] = 100.0 * summary['Victorias_ambas_ext'] / cfg.n_random_aberrations
    dr_mean, dr_std = _mean_std([r['Delta_RMSE_C_ext_minus_conv_rad'] for r in paired_rows])
    dp_mean, dp_std = _mean_std([r['Delta_PSNR_ext_minus_conv_dB'] for r in paired_rows])
    summary['Delta_RMSE_mean'] = dr_mean
    summary['Delta_RMSE_std'] = dr_std
    summary['Delta_PSNR_mean'] = dp_mean
    summary['Delta_PSNR_std'] = dp_std
    return {'coeff_matrix': coeff_matrix, 'detail_rows': rows, 'paired_rows': paired_rows, 'summary_rows': [summary], 'summary': summary}
