from __future__ import annotations
from typing import Sequence
import numpy as np
from skimage.metrics import peak_signal_noise_ratio, structural_similarity
from ..optics_final.system import FourierPDModel, ideal_psf, optical_transfer, strehl_ratio

def coefficient_rmse(estimated: Sequence[float], true_coeffs: Sequence[float]) -> float:
    estimated = np.asarray(estimated, dtype=float)
    true_coeffs = np.asarray(true_coeffs, dtype=float)
    return float(np.sqrt(np.mean((estimated - true_coeffs) ** 2)))

def wavefront_rmse(model: FourierPDModel, estimated: Sequence[float], true_coeffs: Sequence[float]) -> float:
    W_est = model.wavefront(estimated)
    W_true = model.wavefront(true_coeffs)
    mask = model.aperture > 0
    return float(np.sqrt(np.mean((W_est[mask] - W_true[mask]) ** 2)))

def image_metrics(reference: np.ndarray, estimate: np.ndarray) -> dict:
    return {'RMSE_image': float(np.sqrt(np.mean((reference - estimate) ** 2))), 'PSNR': float(peak_signal_noise_ratio(reference, estimate, data_range=1.0)), 'SSIM': float(structural_similarity(reference, estimate, data_range=1.0))}

def result_metrics(model: FourierPDModel, result: dict, true_coeffs: Sequence[float]) -> dict:
    coeffs = result['coeffs']
    met = image_metrics(model.object, result['restored'])
    met['RMSE_C'] = coefficient_rmse(coeffs, true_coeffs)
    met['RMSE_W'] = wavefront_rmse(model, coeffs, true_coeffs)
    psf_ideal = ideal_psf(model)
    psf_true = optical_transfer(model, true_coeffs, {})[1]
    psf_est = optical_transfer(model, coeffs, {})[1]
    met['Strehl_true'] = strehl_ratio(psf_true, psf_ideal)
    met['Strehl_est'] = strehl_ratio(psf_est, psf_ideal)
    return met
