from __future__ import annotations
from dataclasses import replace
from typing import Dict, List, Sequence, Tuple
import numpy as np
from ..algorithms_final.phase_diversity import estimate_pd
from ..config import Config
from ..optics_final.system import FourierPDModel
from ..simulation_final.data import make_dataset, make_noise_bank
from .experiments import conventional_diversities, extended_diversities
from .metrics import result_metrics

def _scaled_coeffs(raw: Sequence[float], target_norm: float) -> Tuple[float, ...]:
    arr = np.asarray(raw, dtype=float)
    norm = float(np.linalg.norm(arr))
    if norm <= 0:
        raise ValueError('La aberración de un caso no puede tener norma nula.')
    return tuple((arr * (target_norm / norm)).tolist())

def build_aberration_cases(cfg: Config) -> List[dict]:
    target_norm = float(np.linalg.norm(np.asarray(cfg.true_coeffs, dtype=float)))
    cases = [{'case': 'Caso_A', 'description': 'Caso base: desenfoque, astigmatismo y coma', 'modes': tuple(cfg.modes), 'coeffs': tuple(cfg.true_coeffs)}, {'case': 'Caso_B', 'description': 'Mezcla con desenfoque, trefoil, coma y esférica', 'modes': (4, 6, 8, 12), 'coeffs': _scaled_coeffs((0.48, -0.34, 0.35, -0.27), target_norm)}, {'case': 'Caso_C', 'description': 'Astigmatismo, coma y trefoil sin desenfoque desconocido', 'modes': (3, 5, 7, 9), 'coeffs': _scaled_coeffs((-0.42, 0.39, -0.32, 0.33), target_norm)}, {'case': 'Caso_D', 'description': 'Caso de mayor dimensión con cinco modos, incluida esférica', 'modes': (4, 5, 7, 8, 12), 'coeffs': _scaled_coeffs((0.42, -0.31, 0.28, -0.25, 0.29), target_norm)}]
    for case in cases:
        case['coeff_norm_rad'] = float(np.linalg.norm(case['coeffs']))
    return cases

def _mean_std(values: Sequence[float]) -> Tuple[float, float]:
    arr = np.asarray(values, dtype=float)
    return (float(np.mean(arr)), float(np.std(arr, ddof=1)) if arr.size > 1 else 0.0)

def run_aberration_case_study(base_cfg: Config, selected_d5: float) -> dict:
    cases = build_aberration_cases(base_cfg)
    detail_rows: List[dict] = []
    representatives: Dict[str, dict] = {}
    for case_idx, case in enumerate(cases):
        cfg = replace(base_cfg, modes=tuple(case['modes']), true_coeffs=tuple(case['coeffs']), run_validations=False, run_d5_selection=False, run_monte_carlo=False, run_regularization_sensitivity=False, run_aberration_cases=False)
        model = FourierPDModel(cfg)
        true_coeffs = np.asarray(cfg.true_coeffs, dtype=float)
        div_conv = conventional_diversities(cfg)
        div_ext = extended_diversities(cfg, selected_d5)
        for seed_idx, seed in enumerate(cfg.aberration_case_seeds):
            noise_bank = make_noise_bank(model.N, K=2, seed=int(seed))
            images_conv = make_dataset(model, true_coeffs, div_conv, cfg.noise_sigma, noise_bank=noise_bank)
            images_ext = make_dataset(model, true_coeffs, div_ext, cfg.noise_sigma, noise_bank=noise_bank)
            result_conv = estimate_pd(model, images_conv, div_conv, cfg, n_starts=cfg.n_starts_cases, maxiter=cfg.maxiter_cases, seed=50000 + 1000 * case_idx + int(seed))
            result_ext = estimate_pd(model, images_ext, div_ext, cfg, n_starts=cfg.n_starts_cases, maxiter=cfg.maxiter_cases, seed=60000 + 1000 * case_idx + int(seed))
            met_conv = result_metrics(model, result_conv, true_coeffs)
            met_ext = result_metrics(model, result_ext, true_coeffs)
            for method, result, met in [('PD convencional', result_conv, met_conv), ('PD extendida', result_ext, met_ext)]:
                detail_rows.append({'Caso': case['case'], 'Descripcion': case['description'], 'Modos': ';'.join((f'Z{j}' for j in cfg.modes)), 'Coeficientes_teoricos_rad': ';'.join((f'{v:.8f}' for v in true_coeffs)), 'Norma_coeficientes_rad': float(np.linalg.norm(true_coeffs)), 'D5_rad': 0.0 if method == 'PD convencional' else float(selected_d5), 'seed': int(seed), 'Metodo': method, 'RMSE_C_rad': met['RMSE_C'], 'RMSE_W_rad': met['RMSE_W'], 'PSNR_dB': met['PSNR'], 'SSIM': met['SSIM'], 'Strehl_true': met['Strehl_true'], 'Strehl_estimado': met['Strehl_est'], 'Funcion_objetivo': result['objective'], 'optimizer_success': result['success'], 'coeficientes_estimados_rad': ';'.join((f'{v:.8f}' for v in result['coeffs']))})
            if seed_idx == 0:
                representatives[case['case']] = {'case': case, 'cfg': cfg, 'model': model, 'true_coeffs': true_coeffs, 'result_conv': result_conv, 'result_ext': result_ext, 'metrics_conv': met_conv, 'metrics_ext': met_ext, 'seed': int(seed)}
        print(f"  Casos de aberración: {case['case']} completado")
    summary_rows: List[dict] = []
    paired_rows: List[dict] = []
    for case in cases:
        case_name = case['case']
        for method in ('PD convencional', 'PD extendida'):
            subset = [r for r in detail_rows if r['Caso'] == case_name and r['Metodo'] == method]
            row = {'Caso': case_name, 'Descripcion': case['description'], 'Modos': ';'.join((f'Z{j}' for j in case['modes'])), 'Norma_coeficientes_rad': case['coeff_norm_rad'], 'Metodo': method, 'N_semillas': len(subset)}
            for key, stem in [('RMSE_C_rad', 'RMSE_C'), ('RMSE_W_rad', 'RMSE_W'), ('PSNR_dB', 'PSNR'), ('SSIM', 'SSIM')]:
                mean, std = _mean_std([r[key] for r in subset])
                row[f'{stem}_mean'] = mean
                row[f'{stem}_std'] = std
            row['optimizer_success_rate'] = float(np.mean([bool(r['optimizer_success']) for r in subset]))
            summary_rows.append(row)
        wins_rmse = 0
        wins_psnr = 0
        deltas_rmse: List[float] = []
        deltas_psnr: List[float] = []
        for seed in base_cfg.aberration_case_seeds:
            conv = next((r for r in detail_rows if r['Caso'] == case_name and r['seed'] == int(seed) and (r['Metodo'] == 'PD convencional')))
            ext = next((r for r in detail_rows if r['Caso'] == case_name and r['seed'] == int(seed) and (r['Metodo'] == 'PD extendida')))
            dr = float(ext['RMSE_C_rad'] - conv['RMSE_C_rad'])
            dp = float(ext['PSNR_dB'] - conv['PSNR_dB'])
            deltas_rmse.append(dr)
            deltas_psnr.append(dp)
            wins_rmse += int(dr < 0)
            wins_psnr += int(dp > 0)
            paired_rows.append({'Caso': case_name, 'seed': int(seed), 'Delta_RMSE_C_ext_minus_conv_rad': dr, 'Delta_PSNR_ext_minus_conv_dB': dp, 'Mejora_RMSE_ext': bool(dr < 0), 'Mejora_PSNR_ext': bool(dp > 0)})
        dr_mean, dr_std = _mean_std(deltas_rmse)
        dp_mean, dp_std = _mean_std(deltas_psnr)
        summary_rows.append({'Caso': case_name, 'Descripcion': case['description'], 'Modos': ';'.join((f'Z{j}' for j in case['modes'])), 'Norma_coeficientes_rad': case['coeff_norm_rad'], 'Metodo': 'Diferencia pareada ext-conv', 'N_semillas': len(base_cfg.aberration_case_seeds), 'RMSE_C_mean': dr_mean, 'RMSE_C_std': dr_std, 'RMSE_W_mean': float('nan'), 'RMSE_W_std': float('nan'), 'PSNR_mean': dp_mean, 'PSNR_std': dp_std, 'SSIM_mean': float('nan'), 'SSIM_std': float('nan'), 'Victorias_RMSE_ext': wins_rmse, 'Victorias_PSNR_ext': wins_psnr})
    return {'cases': cases, 'detail_rows': detail_rows, 'summary_rows': summary_rows, 'paired_rows': paired_rows, 'representatives': representatives, 'selected_d5': float(selected_d5), 'seeds': tuple(base_cfg.aberration_case_seeds)}

def coefficient_rows_from_representatives(study: dict) -> List[dict]:
    rows: List[dict] = []
    for case_name, rep in study['representatives'].items():
        true = np.asarray(rep['true_coeffs'], dtype=float)
        conv = np.asarray(rep['result_conv']['coeffs'], dtype=float)
        ext = np.asarray(rep['result_ext']['coeffs'], dtype=float)
        for j, t, c, e in zip(rep['cfg'].modes, true, conv, ext):
            rows.append({'Caso': case_name, 'seed_representativa': rep['seed'], 'Modo': f'Z{j}', 'Teorico_rad': float(t), 'Estimado_PD_conv_rad': float(c), 'Error_abs_PD_conv_rad': float(abs(c - t)), 'Estimado_PD_ext_rad': float(e), 'Error_abs_PD_ext_rad': float(abs(e - t))})
    return rows
