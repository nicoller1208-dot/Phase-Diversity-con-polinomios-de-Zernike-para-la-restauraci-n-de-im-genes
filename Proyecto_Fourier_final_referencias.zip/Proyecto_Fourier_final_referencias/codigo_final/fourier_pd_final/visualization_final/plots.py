from __future__ import annotations
from pathlib import Path
from typing import Sequence
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import numpy as np
from ..config import Config
from ..optics_final.system import FourierPDModel, ideal_psf, optical_transfer

def plot_validation_gram(model: FourierPDModel, gram: np.ndarray, figures: Path) -> None:
    fig, ax = plt.subplots(figsize=(4.6, 4.0), constrained_layout=True)
    im = ax.imshow(gram, vmin=-1, vmax=1, cmap='RdBu_r')
    labels = [f'Z{j}' for j in model.cfg.modes]
    ax.set_xticks(range(len(labels)), labels)
    ax.set_yticks(range(len(labels)), labels)
    ax.set_title('Matriz de Gram de los modos de Zernike')
    for i in range(len(labels)):
        for j in range(len(labels)):
            ax.text(j, i, f'{gram[i, j]:.3f}', ha='center', va='center', fontsize=8)
    fig.colorbar(im, ax=ax, shrink=0.8)
    fig.savefig(figures / '00_validacion_ortonormalidad.png', dpi=220, bbox_inches='tight')
    plt.close(fig)

def plot_zernike_modes(model: FourierPDModel, figures: Path) -> None:
    labels = {4: 'Z4: desenfoque', 5: 'Z5: astigmatismo', 7: 'Z7: coma', 8: 'Z8: coma'}
    fig, axes = plt.subplots(1, len(model.cfg.modes), figsize=(9.2, 2.4), constrained_layout=True)
    axes = np.atleast_1d(axes)
    im = None
    for ax, j in zip(axes, model.cfg.modes):
        z = np.ma.masked_where(model.aperture == 0, model.Z[j])
        im = ax.imshow(z, origin='lower', cmap='RdBu_r')
        ax.set_title(labels.get(j, f'Z{j}'))
        ax.axis('off')
    if im is not None:
        fig.colorbar(im, ax=axes.tolist(), shrink=0.75, label='amplitud normalizada')
    fig.savefig(figures / '01_modos_zernike.png', dpi=220, bbox_inches='tight')
    plt.close(fig)

def plot_wavefronts(model: FourierPDModel, result_conv: dict, result_ext: dict, figures: Path) -> None:
    true_coeffs = np.asarray(model.cfg.true_coeffs)
    W_true = model.wavefront(true_coeffs)
    W_conv = model.wavefront(result_conv['coeffs'])
    W_ext = model.wavefront(result_ext['coeffs'])
    error_conv = W_conv - W_true
    error_ext = W_ext - W_true
    arrays = [W_true, W_conv, W_ext, error_conv, error_ext]
    titles = ['Frente verdadero', 'Estimado: PD conv.', 'Estimado: PD ext.', 'Error: conv. - verdadero', 'Error: ext. - verdadero']
    vmax = max(np.max(np.abs(W_true)), np.max(np.abs(W_conv)), np.max(np.abs(W_ext)))
    errmax = max(np.max(np.abs(error_conv)), np.max(np.abs(error_ext)), 1e-12)
    fig, axes = plt.subplots(1, 5, figsize=(13.0, 2.8), constrained_layout=True)
    for i, (ax, arr, title) in enumerate(zip(axes, arrays, titles)):
        masked = np.ma.masked_where(model.aperture == 0, arr)
        lim = vmax if i < 3 else errmax
        im = ax.imshow(masked, origin='lower', cmap='RdBu_r', vmin=-lim, vmax=lim)
        ax.set_title(title)
        ax.axis('off')
        fig.colorbar(im, ax=ax, shrink=0.7)
    fig.savefig(figures / '02_frentes_de_onda.png', dpi=220, bbox_inches='tight')
    plt.close(fig)

def plot_psfs(model: FourierPDModel, cfg: Config, selected_d5: float, figures: Path) -> None:
    true_coeffs = np.asarray(cfg.true_coeffs)
    psfs = [ideal_psf(model), optical_transfer(model, true_coeffs, {})[1], optical_transfer(model, true_coeffs, {4: cfg.d4})[1], optical_transfer(model, true_coeffs, {4: cfg.d4, 5: selected_d5})[1]]
    titles = ['PSF ideal', 'PSF aberrada', 'PSF + Z4', f'PSF + Z4 + Z5 ({selected_d5:.2f} rad)']
    c = model.N // 2
    w = min(24, model.N // 4)
    fig, axes = plt.subplots(1, 4, figsize=(10.2, 2.7), constrained_layout=True)
    for ax, psf, title in zip(axes, psfs, titles):
        crop = psf[c - w:c + w + 1, c - w:c + w + 1]
        ax.imshow(np.log10(crop + 1e-12), origin='lower', cmap='magma')
        ax.set_title(title)
        ax.axis('off')
    fig.savefig(figures / '03_psfs.png', dpi=220, bbox_inches='tight')
    plt.close(fig)

def plot_images(main: dict, model: FourierPDModel, figures: Path) -> None:
    arrays = [model.object, np.clip(main['images_conv'][0], 0, 1), np.clip(main['images_conv'][1], 0, 1), np.clip(main['images_ext'][1], 0, 1), main['result_conv']['restored'], main['result_ext']['restored']]
    titles = ['Objeto ideal', 'Referencia aberrada', 'Diversidad convencional: +Z4', 'Diversidad extendida: +Z4+Z5', 'Restaurada: PD conv.', 'Restaurada: PD ext.']
    fig, axes = plt.subplots(2, 3, figsize=(9.0, 5.7), constrained_layout=True)
    for ax, arr, title in zip(axes.ravel(), arrays, titles):
        ax.imshow(arr, cmap='gray', vmin=0, vmax=1)
        ax.set_title(title)
        ax.axis('off')
    fig.savefig(figures / '04_imagenes_y_restauracion.png', dpi=220, bbox_inches='tight')
    plt.close(fig)

def plot_coefficients(model: FourierPDModel, main: dict, figures: Path) -> None:
    true_coeffs = np.asarray(model.cfg.true_coeffs)
    conv = main['result_conv']['coeffs']
    ext = main['result_ext']['coeffs']
    idx = np.arange(len(model.cfg.modes))
    width = 0.25
    fig, axes = plt.subplots(1, 2, figsize=(9.5, 3.5), constrained_layout=True)
    axes[0].bar(idx - width, true_coeffs, width, label='Teórico')
    axes[0].bar(idx, conv, width, label='Estimado PD conv.')
    axes[0].bar(idx + width, ext, width, label='Estimado PD ext.')
    axes[0].set_xticks(idx, [f'Z{j}' for j in model.cfg.modes])
    axes[0].set_ylabel('Coeficiente [rad]')
    axes[0].set_title('Coeficientes teóricos vs. estimados')
    axes[0].grid(axis='y', alpha=0.25)
    axes[0].legend(fontsize=8)
    axes[1].bar(idx - 0.18, np.abs(conv - true_coeffs), 0.36, label='PD conv.')
    axes[1].bar(idx + 0.18, np.abs(ext - true_coeffs), 0.36, label='PD ext.')
    axes[1].set_xticks(idx, [f'Z{j}' for j in model.cfg.modes])
    axes[1].set_ylabel('Error absoluto [rad]')
    axes[1].set_title('Error por modo de Zernike')
    axes[1].grid(axis='y', alpha=0.25)
    axes[1].legend(fontsize=8)
    fig.savefig(figures / '05_coeficientes_teorico_estimado.png', dpi=220, bbox_inches='tight')
    plt.close(fig)

def plot_metrics(main: dict, figures: Path) -> None:
    conv = main['metrics_conv']
    ext = main['metrics_ext']
    metrics = [('RMSE_C', 'RMSE coef. [rad]'), ('RMSE_W', 'RMSE frente [rad]'), ('PSNR', 'PSNR [dB]'), ('SSIM', 'SSIM')]
    fig, axes = plt.subplots(1, 4, figsize=(11.0, 2.9), constrained_layout=True)
    for ax, (key, ylabel) in zip(axes, metrics):
        ax.bar(['Conv.', 'Extendida'], [conv[key], ext[key]])
        ax.set_ylabel(ylabel)
        ax.grid(axis='y', alpha=0.25)
    fig.savefig(figures / '06_metricas.png', dpi=220, bbox_inches='tight')
    plt.close(fig)

def plot_d5_selection(selection: dict, figures: Path) -> None:
    rows = selection['summary_rows']
    if not rows:
        return
    d5 = np.array([r['D5_rad'] for r in rows])
    rm = np.array([r['RMSE_C_mean_rad'] for r in rows])
    rs = np.array([r['RMSE_C_std_rad'] for r in rows])
    pm = np.array([r['PSNR_mean_dB'] for r in rows])
    ps = np.array([r['PSNR_std_dB'] for r in rows])
    selected = selection['selected_d5']
    conv_rmse = rows[0]['Conv_RMSE_C_mean_rad']
    conv_psnr = rows[0]['Conv_PSNR_mean_dB']
    fig, axes = plt.subplots(1, 2, figsize=(8.8, 3.3), constrained_layout=True)
    axes[0].errorbar(d5, rm, yerr=rs, marker='o', capsize=3)
    axes[0].axhline(conv_rmse, linestyle=':', label='Conv. media')
    axes[0].axvline(selected, linestyle='--', label=f'D5 elegido={selected:.2f}')
    axes[0].set_xlabel('D5 [rad]')
    axes[0].set_ylabel('RMSE_C medio [rad]')
    axes[0].grid(alpha=0.25)
    axes[0].legend(fontsize=8)
    axes[1].errorbar(d5, pm, yerr=ps, marker='o', capsize=3)
    axes[1].axhline(conv_psnr, linestyle=':', label='Conv. media')
    axes[1].axvline(selected, linestyle='--', label=f'D5 elegido={selected:.2f}')
    axes[1].set_xlabel('D5 [rad]')
    axes[1].set_ylabel('PSNR medio [dB]')
    axes[1].grid(alpha=0.25)
    axes[1].legend(fontsize=8)
    fig.savefig(figures / '07_seleccion_D5.png', dpi=220, bbox_inches='tight')
    plt.close(fig)

def plot_convergence(main: dict, figures: Path) -> None:
    fig, ax = plt.subplots(figsize=(6.7, 3.3), constrained_layout=True)
    for result, label in [(main['result_conv'], 'PD convencional'), (main['result_ext'], 'PD extendida')]:
        history = np.asarray(result['history'])
        if history.size:
            ax.semilogy(np.arange(1, len(history) + 1), np.minimum.accumulate(history), label=label)
    ax.set_xlabel('Evaluaciones de la función objetivo')
    ax.set_ylabel('Mejor valor acumulado de J')
    ax.set_title('Convergencia del mejor arranque')
    ax.grid(alpha=0.25)
    ax.legend()
    fig.savefig(figures / '08_convergencia.png', dpi=220, bbox_inches='tight')
    plt.close(fig)

def plot_monte_carlo(mc_rows: Sequence[dict], figures: Path) -> None:
    if not mc_rows:
        return
    methods = ['PD convencional', 'PD extendida']
    fig, axes = plt.subplots(1, 2, figsize=(7.6, 3.0), constrained_layout=True)
    for ax, key, ylabel in [(axes[0], 'RMSE_C_rad', 'RMSE_C [rad]'), (axes[1], 'PSNR_dB', 'PSNR [dB]')]:
        means, stds = ([], [])
        for method in methods:
            vals = np.array([r[key] for r in mc_rows if r['Metodo'] == method])
            means.append(float(np.mean(vals)))
            stds.append(float(np.std(vals, ddof=1)) if len(vals) > 1 else 0.0)
        ax.bar(['Conv.', 'Extendida'], means, yerr=stds, capsize=4)
        ax.set_ylabel(ylabel)
        ax.grid(axis='y', alpha=0.25)
    fig.savefig(figures / '09_monte_carlo.png', dpi=220, bbox_inches='tight')
    plt.close(fig)

def plot_regularization_sensitivity(rows: Sequence[dict], figures: Path) -> None:
    if not rows:
        return
    ro_vals = sorted({r['reg_object'] for r in rows})
    rc_vals = sorted({r['reg_coeff'] for r in rows})
    grid_rmse = np.full((len(ro_vals), len(rc_vals)), np.nan)
    grid_psnr = np.full_like(grid_rmse, np.nan)
    for r in rows:
        i = ro_vals.index(r['reg_object'])
        j = rc_vals.index(r['reg_coeff'])
        grid_rmse[i, j] = r['Delta_RMSE_C_ext_minus_conv']
        grid_psnr[i, j] = r['Delta_PSNR_ext_minus_conv_dB']
    fig, axes = plt.subplots(1, 2, figsize=(8.5, 3.5), constrained_layout=True)
    for ax, grid, title in [(axes[0], grid_rmse, 'ΔRMSE_C = ext - conv'), (axes[1], grid_psnr, 'ΔPSNR = ext - conv [dB]')]:
        im = ax.imshow(grid, aspect='auto', origin='lower', cmap='RdBu_r')
        ax.set_xticks(range(len(rc_vals)), [f'{v:g}' for v in rc_vals])
        ax.set_yticks(range(len(ro_vals)), [f'{v:g}' for v in ro_vals])
        ax.set_xlabel('λ coeficientes')
        ax.set_ylabel('λ objeto')
        ax.set_title(title)
        for i in range(grid.shape[0]):
            for j in range(grid.shape[1]):
                ax.text(j, i, f'{grid[i, j]:.3f}', ha='center', va='center', fontsize=7)
        fig.colorbar(im, ax=ax, shrink=0.8)
    fig.savefig(figures / '10_sensibilidad_regularizacion.png', dpi=220, bbox_inches='tight')
    plt.close(fig)

def plot_aberration_case_summary(study: dict, figures: Path) -> None:
    rows = study['summary_rows']
    cases = [c['case'] for c in study['cases']]
    methods = ['PD convencional', 'PD extendida']
    x = np.arange(len(cases))
    width = 0.36
    fig, axes = plt.subplots(1, 2, figsize=(9.2, 3.6), constrained_layout=True)
    for offset, method in [(-width / 2, methods[0]), (width / 2, methods[1])]:
        rm, rs, pm, ps = ([], [], [], [])
        for case in cases:
            r = next((v for v in rows if v['Caso'] == case and v['Metodo'] == method))
            rm.append(r['RMSE_C_mean'])
            rs.append(r['RMSE_C_std'])
            pm.append(r['PSNR_mean'])
            ps.append(r['PSNR_std'])
        axes[0].bar(x + offset, rm, width, yerr=rs, capsize=3, label=method)
        axes[1].bar(x + offset, pm, width, yerr=ps, capsize=3, label=method)
    for ax in axes:
        ax.set_xticks(x, cases)
        ax.grid(axis='y', alpha=0.25)
        ax.legend(fontsize=8)
    axes[0].set_ylabel('RMSE de coeficientes [rad]')
    axes[0].set_title('Robustez frente a distintas aberraciones')
    axes[1].set_ylabel('PSNR [dB]')
    axes[1].set_title('Calidad de reconstrucción')
    fig.savefig(figures / '11_casos_aberracion_metricas.png', dpi=220, bbox_inches='tight')
    plt.close(fig)

def plot_aberration_case_coefficients(study: dict, figures: Path) -> None:
    reps = study['representatives']
    cases = [c['case'] for c in study['cases']]
    fig, axes = plt.subplots(2, 2, figsize=(9.2, 6.2), constrained_layout=True)
    axes = axes.ravel()
    for ax, case_name in zip(axes, cases):
        rep = reps[case_name]
        modes = list(rep['cfg'].modes)
        true = np.asarray(rep['true_coeffs'])
        conv = np.asarray(rep['result_conv']['coeffs'])
        ext = np.asarray(rep['result_ext']['coeffs'])
        x = np.arange(len(modes))
        width = 0.25
        ax.bar(x - width, true, width, label='Teórico')
        ax.bar(x, conv, width, label='PD conv.')
        ax.bar(x + width, ext, width, label='PD ext.')
        ax.set_xticks(x, [f'Z{j}' for j in modes])
        ax.set_ylabel('Coeficiente [rad]')
        ax.set_title(f"{case_name} — seed {rep['seed']}")
        ax.grid(axis='y', alpha=0.25)
        ax.legend(fontsize=7)
    fig.savefig(figures / '12_casos_aberracion_coeficientes.png', dpi=220, bbox_inches='tight')
    plt.close(fig)

def plot_aberration_case_wavefronts(study: dict, figures: Path) -> None:
    reps = study['representatives']
    cases = [c['case'] for c in study['cases']]
    fig, axes = plt.subplots(len(cases), 3, figsize=(8.0, 9.0), constrained_layout=True)
    for i, case_name in enumerate(cases):
        rep = reps[case_name]
        model = rep['model']
        W_true = model.wavefront(rep['true_coeffs'])
        W_conv = model.wavefront(rep['result_conv']['coeffs'])
        W_ext = model.wavefront(rep['result_ext']['coeffs'])
        vmax = max(float(np.max(np.abs(W_true))), float(np.max(np.abs(W_conv))), float(np.max(np.abs(W_ext))), 1e-12)
        for j, (arr, title) in enumerate([(W_true, 'Verdadero'), (W_conv, 'PD conv.'), (W_ext, 'PD ext.')]):
            masked = np.ma.masked_where(model.aperture == 0, arr)
            axes[i, j].imshow(masked, origin='lower', cmap='RdBu_r', vmin=-vmax, vmax=vmax)
            axes[i, j].set_title(f'{case_name}: {title}')
            axes[i, j].axis('off')
    fig.savefig(figures / '13_casos_aberracion_frentes.png', dpi=220, bbox_inches='tight')
    plt.close(fig)

def plot_aberration_case_differences(study: dict, figures: Path) -> None:
    rows = study['paired_rows']
    cases = [c['case'] for c in study['cases']]
    fig, axes = plt.subplots(1, 2, figsize=(8.8, 3.4), constrained_layout=True)
    for i, case in enumerate(cases):
        subset = [r for r in rows if r['Caso'] == case]
        dr = [r['Delta_RMSE_C_ext_minus_conv_rad'] for r in subset]
        dp = [r['Delta_PSNR_ext_minus_conv_dB'] for r in subset]
        axes[0].scatter(np.full(len(dr), i), dr, alpha=0.8)
        axes[1].scatter(np.full(len(dp), i), dp, alpha=0.8)
        axes[0].plot(i, np.mean(dr), marker='D')
        axes[1].plot(i, np.mean(dp), marker='D')
    axes[0].axhline(0, linestyle=':')
    axes[1].axhline(0, linestyle=':')
    axes[0].set_xticks(range(len(cases)), cases)
    axes[1].set_xticks(range(len(cases)), cases)
    axes[0].set_ylabel('ΔRMSE_C ext-conv [rad]')
    axes[1].set_ylabel('ΔPSNR ext-conv [dB]')
    axes[0].set_title('Negativo favorece PD extendida')
    axes[1].set_title('Positivo favorece PD extendida')
    for ax in axes:
        ax.grid(alpha=0.25)
    fig.savefig(figures / '14_casos_aberracion_diferencias.png', dpi=220, bbox_inches='tight')
    plt.close(fig)

def plot_random_aberration_differences(study: dict, figures: Path) -> None:
    rows = study['paired_rows']
    idx = np.asarray([r['Indice'] for r in rows], dtype=int)
    dr = np.asarray([r['Delta_RMSE_C_ext_minus_conv_rad'] for r in rows], dtype=float)
    dp = np.asarray([r['Delta_PSNR_ext_minus_conv_dB'] for r in rows], dtype=float)
    fig, axes = plt.subplots(1, 2, figsize=(9.2, 3.6), constrained_layout=True)
    axes[0].scatter(idx, dr)
    axes[0].axhline(0, linestyle=':')
    axes[0].set_xlabel('Caso aleatorio')
    axes[0].set_ylabel('ΔRMSE_C ext-conv [rad]')
    axes[0].set_title('Negativo favorece PD extendida')
    axes[0].grid(alpha=0.25)
    axes[1].scatter(idx, dp)
    axes[1].axhline(0, linestyle=':')
    axes[1].set_xlabel('Caso aleatorio')
    axes[1].set_ylabel('ΔPSNR ext-conv [dB]')
    axes[1].set_title('Positivo favorece PD extendida')
    axes[1].grid(alpha=0.25)
    fig.savefig(figures / '15_aleatorios_diferencias.png', dpi=220, bbox_inches='tight')
    plt.close(fig)

def plot_random_aberration_coefficients(study: dict, cfg: Config, figures: Path) -> None:
    coeffs = np.asarray(study['coeff_matrix'], dtype=float)
    vmax = max(float(np.max(np.abs(coeffs))), 1e-12)
    fig, ax = plt.subplots(figsize=(7.6, 5.0), constrained_layout=True)
    im = ax.imshow(coeffs, aspect='auto', cmap='RdBu_r', vmin=-vmax, vmax=vmax)
    ax.set_xlabel('Modo de Zernike')
    ax.set_ylabel('Caso aleatorio')
    ax.set_xticks(range(len(cfg.modes)), [f'Z{j}' for j in cfg.modes])
    ax.set_yticks(range(cfg.n_random_aberrations), [f'{i:02d}' for i in range(1, cfg.n_random_aberrations + 1)])
    ax.set_title('Aberraciones sintéticas aleatorias controladas')
    fig.colorbar(im, ax=ax, shrink=0.85, label='Coeficiente [rad]')
    fig.savefig(figures / '16_aleatorios_coeficientes.png', dpi=220, bbox_inches='tight')
    plt.close(fig)

def plot_random_aberration_summary(study: dict, figures: Path) -> None:
    s = study['summary']
    labels = ['Mejora RMSE_C', 'Mejora PSNR', 'Mejora ambas']
    values = [s['Porcentaje_RMSE_ext'], s['Porcentaje_PSNR_ext'], s['Porcentaje_ambas_ext']]
    fig, ax = plt.subplots(figsize=(6.6, 3.8), constrained_layout=True)
    bars = ax.bar(labels, values)
    ax.set_ylim(0, 100)
    ax.set_ylabel('Porcentaje de casos [%]')
    ax.set_title(f"PD extendida en {s['N_casos']} aberraciones aleatorias")
    ax.grid(axis='y', alpha=0.25)
    for bar, value in zip(bars, values):
        ax.text(bar.get_x() + bar.get_width() / 2, value + 2, f'{value:.0f}%', ha='center', va='bottom')
    fig.savefig(figures / '17_aleatorios_resumen.png', dpi=220, bbox_inches='tight')
    plt.close(fig)
